# Keep FFmpegKit (JNI <-> Java callbacks resolved reflectively / from native).
-keep class com.arthenica.ffmpegkit.** { *; }
-keep class com.arthenica.smartexception.** { *; }
-dontwarn com.arthenica.**
