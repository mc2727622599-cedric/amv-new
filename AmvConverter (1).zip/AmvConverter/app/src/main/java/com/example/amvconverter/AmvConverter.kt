package com.example.amvconverter

import com.arthenica.ffmpegkit.FFmpegKit
import com.arthenica.ffmpegkit.FFmpegKitConfig
import com.arthenica.ffmpegkit.FFprobeKit
import com.arthenica.ffmpegkit.ReturnCode
import java.io.File

/**
 * 双向 AMV 转换引擎（基于 FFmpegKit）。
 *
 *  - MP4 → AMV：把普通视频转成廉价 MP3/MP4 播放器用的私有 .amv 格式。
 *  - AMV → MP4：把 .amv 还原成通用的 H.264/AAC MP4。
 *
 * 两个方向都直接调用 FFmpeg 内置的 amv 编解码器（muxer/demuxer `amv`、视频 `amv`、
 * 音频 `adpcm_ima_amv`），这正是产生/消费这些文件的同一套引擎。两个方向均已在 PC 端
 * 用真实样本验证：MP4→AMV 产物结构与 OEM 工具一致；AMV→MP4 能正确解出并得到时长正确的 MP4。
 *
 * 关键格式硬约束（仅影响 MP4→AMV 方向，详见随附 AMV_FORMAT_SPEC.md）：
 *  - 音频采样率锁死 22050 Hz。
 *  - 每个音频块采样数 = 22050 / fps 必须为整数 ⇒ fps 必须整除 22050（故样本 16fps 用 15fps 近似）。
 *  - muxer 需要显式 -block_size = 22050 / fps。
 *  - AMV 必须恰好 1 视频 + 1 音频两条流；源无音轨时注入静音。
 *  - 非 16 倍数的高度需 -strict -1 放行。
 *
 * 反向（AMV→MP4）用 libx264 编码视频——它包含在 ffmpeg-kit 的 full / full-gpl 构建里
 * （CI 默认下载的就是 full-gpl）。若改用不含 libx264 的 min 构建，反向会失败。
 */
object AmvConverter {

    /** adpcm_ima_amv 编码器唯一接受的采样率。 */
    const val SAMPLE_RATE = 22050

    /** 转换方向。 */
    enum class Direction { MP4_TO_AMV, AMV_TO_MP4 }

    /**
     * 一套 AMV 输出参数（仅 MP4→AMV 方向需要）。
     *
     * @param width  输出宽度，必须为偶数（实践中取 16 的倍数最稳）。
     * @param height 输出高度，建议 16 的倍数；非 16 倍数会自动走 -strict -1。
     * @param fps    帧率，必须整除 22050。
     */
    data class AmvProfile(
        val label: String,
        val width: Int,
        val height: Int,
        val fps: Int
    ) {
        /** 每个 01wb 音频块的采样数，等于 muxer 需要的 -block_size。 */
        val blockSize: Int get() = SAMPLE_RATE / fps

        override fun toString(): String = label
    }

    /**
     * 预设列表。第一个刻意匹配样本 DEMO2.amv（160x120），但帧率用 15（最接近其 16fps
     * 的合法值，因为 22050/16 不是整数）。
     */
    val PRESETS: List<AmvProfile> = listOf(
        AmvProfile("160x120 @15fps  (匹配 DEMO2 样本)", 160, 120, 15),
        AmvProfile("160x128 @15fps", 160, 128, 15),
        AmvProfile("208x176 @15fps", 208, 176, 15),
        AmvProfile("320x240 @15fps", 320, 240, 15),
        AmvProfile("160x120 @30fps  (更流畅/更大)", 160, 120, 30)
    )

    /** 转换结果。 */
    sealed class ConvertResult {
        data class Success(val output: File) : ConvertResult()
        data class Failure(val message: String) : ConvertResult()
    }

    // =====================================================================
    //  正向：MP4 → AMV
    // =====================================================================

    /**
     * 把视频转换为 AMV（阻塞当前线程，请在后台线程调用）。
     *
     * @param inputFile  本地输入文件（调用方需先把 SAF 的 URI 拷到 cacheDir）。
     * @param outputFile 本地输出文件（产物，调用方再拷回用户选择的 URI）。
     * @param profile    输出参数。
     * @param onProgress 进度回调，0..100。
     */
    fun mp4ToAmv(
        inputFile: File,
        outputFile: File,
        profile: AmvProfile,
        onProgress: (Int) -> Unit
    ): ConvertResult {
        if (!inputFile.exists() || inputFile.length() == 0L) {
            return ConvertResult.Failure("输入文件不存在或为空：${inputFile.absolutePath}")
        }

        // 探测源：是否有音轨、总时长（用于估算总帧数→进度）。
        val probe = probeInput(inputFile.absolutePath)
        val totalFrames: Long =
            if (probe.durationSec > 0) (probe.durationSec * profile.fps).toLong().coerceAtLeast(1L)
            else 0L

        if (totalFrames > 0) {
            FFmpegKitConfig.enableStatisticsCallback { st ->
                val frame = st.videoFrameNumber.toLong()
                val pct = ((frame * 100) / totalFrames).toInt().coerceIn(0, 99)
                onProgress(pct)
            }
        }

        val args = buildAmvArgs(inputFile, outputFile, profile, hasAudio = probe.hasAudio)
        val session = FFmpegKit.executeWithArguments(args)
        FFmpegKitConfig.enableStatisticsCallback(null)

        return if (ReturnCode.isSuccess(session.returnCode)) {
            if (outputFile.exists() && outputFile.length() > 0) {
                onProgress(100)
                ConvertResult.Success(outputFile)
            } else {
                ConvertResult.Failure("FFmpeg 返回成功，但未生成有效输出文件。")
            }
        } else {
            val log = session.allLogsAsString?.takeLast(4000).orEmpty()
            ConvertResult.Failure("转换失败（returnCode=${session.returnCode}）。\n\n日志：\n$log")
        }
    }

    // =====================================================================
    //  反向：AMV → MP4
    // =====================================================================

    /**
     * 把 AMV 还原为通用 MP4（H.264 + AAC）。阻塞当前线程，请在后台线程调用。
     *
     * 保留源的分辨率与帧率，仅重新编码到通用编码格式，让任意手机/电脑都能播放。
     *
     * @param inputFile  本地 .amv 输入文件。
     * @param outputFile 本地 .mp4 输出文件。
     * @param onProgress 进度回调，0..100（AMV 头不含可靠时长，进度按实际帧数估算）。
     */
    fun amvToMp4(
        inputFile: File,
        outputFile: File,
        onProgress: (Int) -> Unit
    ): ConvertResult {
        if (!inputFile.exists() || inputFile.length() == 0L) {
            return ConvertResult.Failure("输入文件不存在或为空：${inputFile.absolutePath}")
        }

        // AMV 头里的时长/帧数往往无效，所以直接数一遍真实帧数来做进度分母（AMV 通常很小，开销可接受）。
        val totalFrames = countVideoFrames(inputFile.absolutePath)
        if (totalFrames > 0) {
            FFmpegKitConfig.enableStatisticsCallback { st ->
                val frame = st.videoFrameNumber.toLong()
                val pct = ((frame * 100) / totalFrames).toInt().coerceIn(0, 99)
                onProgress(pct)
            }
        }

        val args = buildMp4Args(inputFile, outputFile)
        val session = FFmpegKit.executeWithArguments(args)
        FFmpegKitConfig.enableStatisticsCallback(null)

        return if (ReturnCode.isSuccess(session.returnCode)) {
            if (outputFile.exists() && outputFile.length() > 0) {
                onProgress(100)
                ConvertResult.Success(outputFile)
            } else {
                ConvertResult.Failure("FFmpeg 返回成功，但未生成有效输出文件。")
            }
        } else {
            val log = session.allLogsAsString?.takeLast(4000).orEmpty()
            // 反向最常见的失败是用了不含 libx264 的精简构建，这里顺带提示一下。
            val hint =
                if (log.contains("Unknown encoder", ignoreCase = true) ||
                    log.contains("libx264", ignoreCase = true)
                ) "\n\n提示：AMV→MP4 需要含 libx264 的 ffmpeg-kit 构建（full / full-gpl）；" +
                    "min 构建不含视频编码器。请改用 full-gpl 的 AAR。"
                else ""
            ConvertResult.Failure("转换失败（returnCode=${session.returnCode}）。$hint\n\n日志：\n$log")
        }
    }

    // =====================================================================
    //  内部工具
    // =====================================================================

    /** 探测结果。 */
    private data class ProbeInfo(val hasAudio: Boolean, val durationSec: Double)

    private fun probeInput(path: String): ProbeInfo {
        return try {
            val session = FFprobeKit.getMediaInformation(path)
            val info = session.mediaInformation
            val hasAudio = info?.streams?.any { it.type == "audio" } == true
            val dur = info?.duration?.toDoubleOrNull() ?: 0.0
            ProbeInfo(hasAudio, dur)
        } catch (e: Exception) {
            // 探测失败不致命：当作有音轨、未知时长（进度条可能不动，但转换照常）。
            ProbeInfo(hasAudio = true, durationSec = 0.0)
        }
    }

    /** 数视频流的实际帧数；失败返回 0（进度退化为不精确，但不影响转换）。 */
    private fun countVideoFrames(path: String): Long {
        return try {
            val session = FFprobeKit.executeWithArguments(
                arrayOf(
                    "-v", "error",
                    "-count_frames",
                    "-select_streams", "v:0",
                    "-show_entries", "stream=nb_read_frames",
                    "-of", "csv=p=0",
                    path
                )
            )
            val out = session.allLogsAsString.orEmpty()
            out.lineSequence()
                .map { it.trim() }
                .firstOrNull { it.matches(Regex("\\d+")) }
                ?.toLongOrNull() ?: 0L
        } catch (e: Exception) {
            0L
        }
    }

    /**
     * 构造 MP4→AMV 的 FFmpeg 参数（必须用 String[]：每个 token 独立，避免 -vf 滤镜里的逗号/冒号被错误拆分）。
     *
     * 验证过的配方（含音轨）：
     *   ffmpeg -y -i IN
     *     -vf "scale=W:H:force_original_aspect_ratio=decrease,pad=W:H:(ow-iw)/2:(oh-ih)/2:black,fps=FPS,format=yuvj420p"
     *     -c:v amv -strict -1 -c:a adpcm_ima_amv -ar 22050 -ac 1 -block_size BS -f amv OUT
     *
     * 无音轨时：额外用 anullsrc 注入静音，并显式 -map 选流 + -shortest。
     */
    private fun buildAmvArgs(
        inputFile: File,
        outputFile: File,
        p: AmvProfile,
        hasAudio: Boolean
    ): Array<String> {
        val w = p.width
        val h = p.height
        val bs = p.blockSize

        val vf =
            "scale=$w:$h:force_original_aspect_ratio=decrease," +
            "pad=$w:$h:(ow-iw)/2:(oh-ih)/2:black," +
            "fps=${p.fps}," +
            "format=yuvj420p"

        val args = ArrayList<String>()
        args.add("-y")

        args.add("-i"); args.add(inputFile.absolutePath)
        if (!hasAudio) {
            args.add("-f"); args.add("lavfi")
            args.add("-i"); args.add("anullsrc=channel_layout=mono:sample_rate=$SAMPLE_RATE")
        }

        args.add("-map"); args.add("0:v:0")
        if (hasAudio) {
            args.add("-map"); args.add("0:a:0")
        } else {
            args.add("-map"); args.add("1:a:0")
        }

        args.add("-vf"); args.add(vf)
        args.add("-c:v"); args.add("amv")
        args.add("-strict"); args.add("-1")

        args.add("-c:a"); args.add("adpcm_ima_amv")
        args.add("-ar"); args.add(SAMPLE_RATE.toString())
        args.add("-ac"); args.add("1")
        args.add("-block_size"); args.add(bs.toString())

        if (!hasAudio) {
            args.add("-shortest")
        }

        args.add("-f"); args.add("amv")
        args.add(outputFile.absolutePath)

        return args.toTypedArray()
    }

    /**
     * 构造 AMV→MP4 的 FFmpeg 参数。
     *
     * 验证过的配方：
     *   ffmpeg -y -i IN.amv -c:v libx264 -pix_fmt yuv420p -crf 23
     *     -c:a aac -b:a 96k -ar 22050 -movflags +faststart -f mp4 OUT.mp4
     *
     * 说明：AMV 视频是 yuvj420p(全范围)，统一转 yuv420p 以获得最广播放器兼容性；
     * +faststart 把索引前置，便于边下边播。
     */
    private fun buildMp4Args(inputFile: File, outputFile: File): Array<String> {
        return arrayOf(
            "-y",
            "-i", inputFile.absolutePath,
            "-c:v", "libx264",
            "-pix_fmt", "yuv420p",
            "-crf", "23",
            "-c:a", "aac",
            "-b:a", "96k",
            "-ar", SAMPLE_RATE.toString(),
            "-movflags", "+faststart",
            "-f", "mp4",
            outputFile.absolutePath
        )
    }
}
