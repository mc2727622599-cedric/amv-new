package com.example.amvconverter

import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.view.View
import android.widget.ArrayAdapter
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.example.amvconverter.AmvConverter.Direction
import com.example.amvconverter.databinding.ActivityMainBinding
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    /** 当前转换方向。 */
    private var direction = Direction.MP4_TO_AMV

    /** 用户选中的输入文件。 */
    private var inputUri: Uri? = null
    private var inputName: String? = null

    /** AMV 输出参数（仅正向使用）。 */
    private val profiles = AmvConverter.PRESETS
    private var selectedProfile = profiles.first()

    /** 选择输入文件。 */
    private val pickFile =
        registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            if (uri != null) {
                inputUri = uri
                inputName = queryDisplayName(uri)
                binding.tvInputFile.text = inputName ?: uri.toString()
                binding.btnConvert.isEnabled = true
                setStatus("已选择输入：${inputName ?: uri}")
            }
        }

    /** 创建输出文件，拿到 URI 后立即开始转换。用 "*/*" 通用类型，靠文件名后缀区分 .amv/.mp4。 */
    private val createOutput =
        registerForActivityResult(ActivityResultContracts.CreateDocument("*/*")) { uri ->
            if (uri != null) {
                startConversion(uri)
            } else {
                setBusy(false)
                setStatus("已取消保存。")
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // 方向选择。
        binding.rgDirection.setOnCheckedChangeListener { _, checkedId ->
            direction = if (checkedId == binding.rbToMp4.id) Direction.AMV_TO_MP4 else Direction.MP4_TO_AMV
            onDirectionChanged()
        }

        // AMV 参数下拉框。
        val adapter = ArrayAdapter(
            this,
            android.R.layout.simple_spinner_item,
            profiles
        ).also { it.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item) }
        binding.spinnerProfile.adapter = adapter
        binding.spinnerProfile.onItemSelectedListener =
            object : android.widget.AdapterView.OnItemSelectedListener {
                override fun onItemSelected(
                    parent: android.widget.AdapterView<*>?, view: View?, position: Int, id: Long
                ) {
                    selectedProfile = profiles[position]
                }
                override fun onNothingSelected(parent: android.widget.AdapterView<*>?) {}
            }

        binding.btnPick.setOnClickListener {
            pickFile.launch(inputMimeFilter())
        }

        binding.btnConvert.setOnClickListener {
            val name = inputName ?: "output"
            val base = name.substringBeforeLast('.', name)
            val outName = if (direction == Direction.MP4_TO_AMV) "$base.amv" else "$base.mp4"
            setBusy(true)
            setStatus("选择输出位置…")
            createOutput.launch(outName)
        }

        binding.btnConvert.isEnabled = false
        binding.progress.progress = 0
        onDirectionChanged()
    }

    /** 方向变化时刷新界面文案、参数区可见性，并清空已选输入（类型不同）。 */
    private fun onDirectionChanged() {
        inputUri = null
        inputName = null
        binding.tvInputFile.text = "尚未选择文件"
        binding.btnConvert.isEnabled = false
        updateProgress(0)

        if (direction == Direction.MP4_TO_AMV) {
            binding.btnPick.text = "选择 MP4 文件…"
            binding.profileSection.visibility = View.VISIBLE
            binding.btnConvert.text = "转换为 AMV"
            setStatus("模式：MP4 → AMV")
        } else {
            binding.btnPick.text = "选择 AMV 文件…"
            binding.profileSection.visibility = View.GONE
            binding.btnConvert.text = "转换为 MP4"
            setStatus("模式：AMV → MP4")
        }
    }

    /** 输入文件选择器的 MIME 过滤：MP4 用 video/*；AMV 系统多半不认识，用 */* 才能选到。 */
    private fun inputMimeFilter(): Array<String> =
        if (direction == Direction.MP4_TO_AMV) arrayOf("video/*") else arrayOf("*/*")

    /** 转换流程：拷贝输入→引擎→拷贝输出→清理。 */
    private fun startConversion(outputUri: Uri) {
        val srcUri = inputUri
        if (srcUri == null) {
            setBusy(false)
            toast("请先选择输入文件")
            return
        }
        val dir = direction
        val profile = selectedProfile

        lifecycleScope.launch {
            updateProgress(0)
            setStatus("准备中：拷贝输入文件…")

            val result = withContext(Dispatchers.IO) {
                val inExt = if (dir == Direction.MP4_TO_AMV) "mp4" else "amv"
                val outExt = if (dir == Direction.MP4_TO_AMV) "amv" else "mp4"
                val cacheIn = File(cacheDir, "amv_in.$inExt")
                val cacheOut = File(cacheDir, "amv_out.$outExt")
                cacheIn.delete(); cacheOut.delete()

                // 1) SAF URI → cacheDir 本地文件。
                try {
                    contentResolver.openInputStream(srcUri).use { input ->
                        if (input == null) error("无法打开输入文件")
                        cacheIn.outputStream().use { input.copyTo(it) }
                    }
                } catch (e: Exception) {
                    return@withContext AmvConverter.ConvertResult.Failure("拷贝输入失败：${e.message}")
                }

                runOnUiThread { setStatus("转换中…") }

                // 2) 按方向执行。
                val r = if (dir == Direction.MP4_TO_AMV) {
                    AmvConverter.mp4ToAmv(cacheIn, cacheOut, profile) { pct ->
                        runOnUiThread { updateProgress(pct) }
                    }
                } else {
                    AmvConverter.amvToMp4(cacheIn, cacheOut) { pct ->
                        runOnUiThread { updateProgress(pct) }
                    }
                }

                // 3) 成功则把产物拷回用户选择的 URI。
                if (r is AmvConverter.ConvertResult.Success) {
                    try {
                        contentResolver.openOutputStream(outputUri).use { out ->
                            if (out == null) error("无法打开输出位置")
                            cacheOut.inputStream().use { it.copyTo(out) }
                        }
                    } catch (e: Exception) {
                        cacheIn.delete(); cacheOut.delete()
                        return@withContext AmvConverter.ConvertResult.Failure("写出结果失败：${e.message}")
                    }
                }

                // 4) 清理临时文件。
                cacheIn.delete(); cacheOut.delete()
                r
            }

            setBusy(false)
            when (result) {
                is AmvConverter.ConvertResult.Success -> {
                    updateProgress(100)
                    val what = if (dir == Direction.MP4_TO_AMV) ".amv" else ".mp4"
                    setStatus("完成！已保存为 $what 文件。")
                    toast("转换完成")
                }
                is AmvConverter.ConvertResult.Failure -> {
                    setStatus("失败：\n${result.message}")
                    toast("转换失败")
                }
            }
        }
    }

    // ---- UI 小工具 ----

    private fun setBusy(busy: Boolean) {
        binding.btnConvert.isEnabled = !busy && inputUri != null
        binding.btnPick.isEnabled = !busy
        binding.spinnerProfile.isEnabled = !busy
        binding.rbToAmv.isEnabled = !busy
        binding.rbToMp4.isEnabled = !busy
    }

    private fun updateProgress(pct: Int) {
        binding.progress.progress = pct
        binding.tvPercent.text = "$pct%"
    }

    private fun setStatus(msg: String) {
        binding.tvStatus.text = msg
    }

    private fun toast(msg: String) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
    }

    /** 从 content URI 取显示文件名。 */
    private fun queryDisplayName(uri: Uri): String? {
        return try {
            contentResolver.query(uri, null, null, null, null)?.use { c ->
                val idx = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (idx >= 0 && c.moveToFirst()) c.getString(idx) else null
            }
        } catch (e: Exception) {
            null
        }
    }
}
