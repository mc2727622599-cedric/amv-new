# 安卓方案二:原生 App(Android Studio 工程)

与 Windows 版转换器同一套已验证的转换参数;ffmpeg 以内置可执行文件方式集成,
不依赖任何第三方 Maven 库(FFmpegKit 已于 2025 年退役、二进制已下架,故弃用)。

## 推荐:GitHub 云端构建(零本地环境)

见《GitHub云端构建APK教程.md》——把工程推到 GitHub,
Actions 会自动从源码编译 arm64 静态版 ffmpeg 并产出可安装的 APK,
你本地什么都不用装。

## 备选:本地 Android Studio 构建

1. 获取 libffmpeg.so:最简单的方式是先跑一次 GitHub Actions,
   从 Artifacts 里下载 libffmpeg-arm64;或自行用 NDK 按
   .github/workflows/build-apk.yml 里的 configure 参数编译。
   把它放入 `app/src/main/jniLibs/arm64-v8a/`。
2. Android Studio 打开本工程根目录,等 Gradle 同步完成。
3. 连手机点 Run ▶,或 Build → Generate Signed APK。

## App 使用

选择输入文件(.amv → 转 MP4;.mp4/.mkv/.avi… → 转 AMV)→
需要时调整帧率/分辨率 → 点"开始转换"。
结果自动保存到手机的 下载/Download 目录,无需任何存储权限。

## 技术要点

- AMV 输出遵守逆向得到的硬约束:22050Hz 单声道 ADPCM、
  每块样本数 = 22050/帧率(帧率仅 10/14/15/18/21/25/30 可选)、
  `-strict -1` 放行非 16 倍数高度、`-block_size` 对齐音频分块。
- MP4 输出用 ffmpeg 内置 mpeg4+aac 编码器(自编静态版不含 libx264;
  mpeg4 通用可播,要 H.264 的话拿到电脑上用 Windows 版再转一次即可)。
- ffmpeg 伪装成 libffmpeg.so 打进 APK;Android 10+ 只允许执行
  nativeLibraryDir 里的文件,工程已配好 extractNativeLibs="true" +
  jniLibs.useLegacyPackaging = true。
- SAF 选文件 + MediaStore 写下载目录,全程零存储权限,兼容 Android 10+。

## 已知限制

- 只内置 arm64-v8a;如需 32 位老设备,把工作流里的编译目标改为
  armv7a 再加一份 jniLibs/armeabi-v7a/libffmpeg.so,
  并在 abiFilters 里加 "armeabi-v7a"。
- 工程未经我本机真机编译(我的环境无安卓 SDK);转换命令与
  Windows 版一致、已验证。构建报错的话把日志发给我。
