plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.amv.converter"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.amv.converter"
        minSdk = 29            // Android 10+
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"
        ndk { abiFilters += listOf("arm64-v8a") }
    }

    // 关键:安装时把 jniLibs 解压到磁盘,才能以可执行文件方式运行 ffmpeg
    packaging { jniLibs { useLegacyPackaging = true } }

    buildTypes {
        release { isMinifyEnabled = false }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}

dependencies { }   // 零第三方依赖,规避 FFmpegKit 停更的供应链问题
