package com.amv.converter

import android.app.Activity
import android.content.ContentValues
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.provider.OpenableColumns
import android.widget.*
import java.io.File
import kotlin.concurrent.thread

class MainActivity : Activity() {

    private lateinit var btnPick: Button
    private lateinit var btnConvert: Button
    private lateinit var txtFile: TextView
    private lateinit var txtDirection: TextView
    private lateinit var txtLog: TextView
    private lateinit var scroll: ScrollView
    private lateinit var spFps: Spinner
    private lateinit var spSize: Spinner

    private var inputName: String? = null   // 原始文件名(含扩展名)
    private var inputFile: File? = null     // 拷贝到 cache 的本地副本

    private val REQ_OPEN = 1

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        btnPick = findViewById(R.id.btnPick)
        btnConvert = findViewById(R.id.btnConvert)
        txtFile = findViewById(R.id.txtFile)
        txtDirection = findViewById(R.id.txtDirection)
        txtLog = findViewById(R.id.txtLog)
        scroll = findViewById(R.id.scroll)
        spFps = findViewById(R.id.spFps)
        spSize = findViewById(R.id.spSize)

        spFps.adapter = ArrayAdapter(
            this, android.R.layout.simple_spinner_dropdown_item,
            FFmpegRunner.VALID_AMV_FPS.map { it.toString() })
        spFps.setSelection(FFmpegRunner.VALID_AMV_FPS.indexOf(15))
        spSize.adapter = ArrayAdapter(
            this, android.R.layout.simple_spinner_dropdown_item, FFmpegRunner.AMV_SIZES)

        btnPick.setOnClickListener {
            val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                addCategory(Intent.CATEGORY_OPENABLE)
                type = "*/*"   // .amv 没有标准 MIME,放开全部
            }
            startActivityForResult(i, REQ_OPEN)
        }

        btnConvert.setOnClickListener { startConvert() }

        if (FFmpegRunner.isReady(this)) {
            log("ffmpeg 就绪:${FFmpegRunner.ffmpegPath(this).absolutePath}")
            log("选择文件后点击“开始转换”。输出保存在 下载/Download 目录。")
        } else {
            log("⚠ 未找到内置 ffmpeg!")
            log("请按 README 把 arm64 静态版 ffmpeg 重命名为 libffmpeg.so,")
            log("放入 app/src/main/jniLibs/arm64-v8a/ 后重新构建安装。")
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != REQ_OPEN || resultCode != RESULT_OK) return
        val uri = data?.data ?: return
        val name = queryDisplayName(uri) ?: "input.bin"
        inputName = name
        txtFile.text = name
        txtDirection.text = if (name.lowercase().endsWith(".amv"))
            "方向:AMV → MP4(H.264 + AAC)"
        else
            "方向:视频 → AMV(无头MJPEG + IMA-ADPCM 22050Hz 单声道)"
        // SAF 的 Uri 不能直接喂给 ffmpeg,先拷贝成本地文件
        log("正在导入文件…")
        btnConvert.isEnabled = false
        thread {
            val dst = File(cacheDir, "in_${name}")
            contentResolver.openInputStream(uri)!!.use { ins ->
                dst.outputStream().use { ins.copyTo(it) }
            }
            inputFile = dst
            runOnUiThread {
                log("已导入:${dst.length() / 1024} KB")
                btnConvert.isEnabled = true
            }
        }
    }

    private fun startConvert() {
        val src = inputFile ?: return
        val name = inputName ?: return
        val base = name.substringBeforeLast('.')
        val toAmv = !name.lowercase().endsWith(".amv")
        val outName = base + if (toAmv) ".amv" else ".mp4"
        val outTmp = File(cacheDir, "out_$outName")

        val fps = spFps.selectedItem.toString().toInt()
        val size = spSize.selectedItem.toString()

        btnConvert.isEnabled = false
        btnConvert.text = "转换中…"
        thread {
            try {
                val cmd = FFmpegRunner.buildCommand(this, src, outTmp, fps, size)
                log("命令:" + cmd.joinToString(" "))
                val rc = FFmpegRunner.run(cmd) { line -> log(line) }
                if (rc == 0) {
                    val saved = saveToDownloads(outTmp, outName, toAmv)
                    log("✔ 完成:已保存到 下载/Download/$outName")
                    log("  (${outTmp.length() / 1024} KB)")
                    if (!saved) log("⚠ 写入下载目录失败,文件仍在应用缓存:${outTmp.absolutePath}")
                } else {
                    log("✘ 失败,ffmpeg 返回码 $rc")
                }
            } catch (e: Exception) {
                log("✘ ${e.message}")
            } finally {
                runOnUiThread {
                    btnConvert.isEnabled = true
                    btnConvert.text = "开始转换"
                }
            }
        }
    }

    /** 通过 MediaStore 把结果写入公共“下载”目录(无需任何存储权限,API 29+)。 */
    private fun saveToDownloads(f: File, displayName: String, isAmv: Boolean): Boolean {
        return try {
            val values = ContentValues().apply {
                put(MediaStore.MediaColumns.DISPLAY_NAME, displayName)
                put(MediaStore.MediaColumns.MIME_TYPE,
                    if (isAmv) "application/octet-stream" else "video/mp4")
            }
            val uri: Uri = contentResolver.insert(
                MediaStore.Downloads.EXTERNAL_CONTENT_URI, values) ?: return false
            contentResolver.openOutputStream(uri)!!.use { out ->
                f.inputStream().use { it.copyTo(out) }
            }
            true
        } catch (e: Exception) {
            false
        }
    }

    private fun queryDisplayName(uri: Uri): String? =
        contentResolver.query(uri, null, null, null, null)?.use { c ->
            val idx = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            if (idx >= 0 && c.moveToFirst()) c.getString(idx) else null
        }

    private fun log(s: String) = runOnUiThread {
        txtLog.append(s + "\n")
        scroll.post { scroll.fullScroll(ScrollView.FOCUS_DOWN) }
    }
}
