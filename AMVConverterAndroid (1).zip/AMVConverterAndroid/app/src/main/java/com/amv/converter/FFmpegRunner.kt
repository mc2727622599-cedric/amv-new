package com.amv.converter

import android.content.Context
import java.io.File

/**
 * 负责定位 App 内置的 ffmpeg 可执行文件,并按照逆向分析得到的
 * AMV 格式约束构造转换命令(与 Windows 版转换器参数完全一致)。
 *
 * ffmpeg 以 jniLibs/arm64-v8a/libffmpeg.so 的名义打进 APK;
 * 安装后位于 nativeLibraryDir,该目录下的文件允许被 exec
 * (Android 10+ 的 W^X 限制对 nativeLibraryDir 放行)。
 */
object FFmpegRunner {

    /** 帧率必须整除 22050(每个视频帧配一个音频块,块样本数 = 22050/fps) */
    val VALID_AMV_FPS = listOf(10, 14, 15, 18, 21, 25, 30)
    val AMV_SIZES = listOf("160x120", "128x96", "128x128", "208x176", "320x240")

    fun ffmpegPath(ctx: Context): File =
        File(ctx.applicationInfo.nativeLibraryDir, "libffmpeg.so")

    fun isReady(ctx: Context): Boolean = ffmpegPath(ctx).canExecute()

    /** 构造命令。dst 扩展名为 .amv 时走 MP4→AMV,否则走 AMV→MP4。 */
    fun buildCommand(
        ctx: Context, src: File, dst: File,
        fps: Int, size: String
    ): List<String> {
        val ff = ffmpegPath(ctx).absolutePath
        return if (dst.extension.lowercase() == "amv") {
            require(fps in VALID_AMV_FPS) { "AMV 帧率必须整除 22050" }
            val (w, h) = size.split("x").map { it.toInt() }
            val block = 22050 / fps
            listOf(
                ff, "-y", "-hide_banner", "-i", src.absolutePath,
                "-vf", "scale=$w:$h:force_original_aspect_ratio=decrease," +
                        "pad=$w:$h:(ow-iw)/2:(oh-ih)/2,fps=$fps",
                "-c:v", "amv", "-strict", "-1",
                "-c:a", "adpcm_ima_amv", "-ar", "22050", "-ac", "1",
                "-block_size", block.toString(),
                dst.absolutePath
            )
        } else {
            // 自编译的静态版 ffmpeg 不含 libx264,使用内置 mpeg4 编码器
            // (所有播放器都能放;如需 H.264 可在电脑上用 Windows 版再转一次)
            listOf(
                ff, "-y", "-hide_banner", "-i", src.absolutePath,
                "-vf", "scale=trunc(iw/2)*2:trunc(ih/2)*2",
                "-c:v", "mpeg4", "-pix_fmt", "yuv420p", "-q:v", "4",
                "-c:a", "aac", "-b:a", "160k",
                "-movflags", "+faststart",
                dst.absolutePath
            )
        }
    }

    /**
     * 执行转换;onLine 回调 ffmpeg 输出行(已过滤为进度/错误行)。
     * @return ffmpeg 退出码,0 为成功
     */
    fun run(cmd: List<String>, onLine: (String) -> Unit): Int {
        val proc = ProcessBuilder(cmd).redirectErrorStream(true).start()
        proc.inputStream.bufferedReader().forEachLine { line ->
            if (line.startsWith("frame=") || line.contains("time=") ||
                line.contains("Error") || line.contains("Invalid")
            ) onLine(line.trim())
        }
        return proc.waitFor()
    }
}
