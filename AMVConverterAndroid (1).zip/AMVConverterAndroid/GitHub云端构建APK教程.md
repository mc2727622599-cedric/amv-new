# 用 GitHub 云端自动构建 APK(零本地环境)

工程里已内置 GitHub Actions 工作流(`.github/workflows/build-apk.yml`),
推到 GitHub 后会自动完成两件事:
1. 用 GitHub 服务器自带的 Android NDK,从 ffmpeg 官方源码编译 arm64 静态版
   ffmpeg(约 10 分钟,之后有缓存秒过)——不依赖任何第三方下载站;
2. 注入为 libffmpeg.so 并构建出可安装的 APK。

你的电脑上不需要装 Android Studio、JDK、NDK 中的任何一个。

## 步骤(全程网页操作即可)

1. **建仓库**:登录 GitHub → 右上角 + → New repository →
   名字随意(如 amv-converter)→ 选 Private(私有)→ Create。

2. **上传工程**:进入仓库页 → Add file → Upload files →
   把本压缩包解压后,将 AMVConverterAndroid 文件夹里的【全部内容】
   (settings.gradle.kts、app/、.github/ 等)拖进去 → Commit changes。

   ⚠ 两个易错点:
   - 上传的是文件夹"里面的内容",settings.gradle.kts 必须位于仓库根目录;
   - `.github` 是隐藏文件夹,网页拖拽时别漏掉(Windows 资源管理器里
     看不到的话,先开"显示隐藏的项目")。
     如果网页上传实在带不上 .github,可以在仓库里 Add file →
     Create new file → 文件名输入 `.github/workflows/build-apk.yml`
     → 把工作流文件内容粘贴进去提交。

3. **触发构建**:上传完成即自动触发;也可以到仓库的 Actions 标签页 →
   左侧选 "Build APK" → Run workflow 手动触发。
   首次构建约 12–15 分钟(主要耗在编译 ffmpeg,之后有缓存约 3 分钟)。

4. **下载 APK**:Actions → 点进刚完成的那次运行(绿色 ✔)→
   页面底部 Artifacts → 下载 **AMV-Converter-APK** → 解压得到
   app-debug.apk → 传到手机安装(需允许"安装未知来源应用")。

   旁边还有一个 **libffmpeg-arm64** 产物,是编译好的 ffmpeg 二进制,
   想在本地 Android Studio 构建时直接拿它放进
   app/src/main/jniLibs/arm64-v8a/ 即可,不用自己找。

## 常见问题

- **Actions 页面提示 workflows 被禁用**:仓库 Settings → Actions →
  General → 选 "Allow all actions" 保存。
- **构建失败**:点进失败的运行,把红色步骤的日志贴给我。
- **APK 装不上**:确认手机是 64 位 ARM(2016 年后的机型基本都是);
  本工程默认只打 arm64-v8a。
- 这是 debug 签名的 APK,自用没问题;如要分发,可在工作流里
  增加签名步骤(需要的话告诉我,我把签名配置加上)。
