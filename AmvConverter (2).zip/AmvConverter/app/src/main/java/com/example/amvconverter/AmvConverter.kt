package com.example.amvconverter

import android.media.MediaMetadataRetriever
import com.arthenica.ffmpegkit.FFmpegKit
import com.arthenica.ffmpegkit.FFmpegKitConfig
import com.arthenica.ffmpegkit.ReturnCode
import java.io.File

// 双向 AMV 转换引擎（基于 FFmpegKit）。
//
//   MP4 到 AMV：把普通视频转成廉价 MP3/MP4 播放器用的私有 AMV 格式。
//   AMV 到 MP4：把 AMV 还原成通用的 H.264 加 AAC 的 MP4。
//
// 设计原则（吸取多次编译失败的教训）：只使用经编译验证存在于库中的核心类
// FFmpegKit / FFmpegKitConfig / ReturnCode。媒体信息探测改用安卓系统自带的
// MediaMetadataRetriever，不依赖该库里可能缺失的 FFprobeKit。
//
// 关键格式硬约束（仅影响 MP4 到 AMV 方向，详见随附 AMV_FORMAT_SPEC.md）：
//   - 音频采样率锁死 22050 Hz。
//   - 每个音频块采样数 = 22050 除以 fps，必须为整数，所以 fps 必须整除 22050
//     （故样本的 16fps 用 15fps 近似）。
//   - muxer 需要显式 block_size = 22050 除以 fps。
//   - AMV 必须恰好 1 视频加 1 音频两条流；源无音轨时注入静音。
//   - 非 16 倍数的高度需 strict 放行。
//
// 反向（AMV 到 MP4）用 libx264 编码视频；它包含在 full / full-gpl 构建里。
object AmvConverter {

    // adpcm_ima_amv 编码器唯一接受的采样率。
    const val SAMPLE_RATE = 22050

    // 转换方向。
    enum class Direction { MP4_TO_AMV, AMV_TO_MP4 }

    // 一套 AMV 输出参数（仅 MP4 到 AMV 方向需要）。
    // width 必须为偶数（实践中取 16 的倍数最稳）；height 建议 16 的倍数；fps 必须整除 22050。
    data class AmvProfile(
        val label: String,
        val width: Int,
        val height: Int,
        val fps: Int
    ) {
        // 每个音频块的采样数，等于 muxer 需要的 block_size。
        val blockSize: Int get() = SAMPLE_RATE / fps

        override fun toString(): String = label
    }

    // 预设列表。第一个刻意匹配样本 DEMO2.amv（160x120），帧率用 15（最接近其 16fps 的合法值）。
    val PRESETS: List<AmvProfile> = listOf(
        AmvProfile("160x120 @15fps  (匹配 DEMO2 样本)", 160, 120, 15),
        AmvProfile("160x128 @15fps", 160, 128, 15),
        AmvProfile("208x176 @15fps", 208, 176, 15),
        AmvProfile("320x240 @15fps", 320, 240, 15),
        AmvProfile("160x120 @30fps  (更流畅/更大)", 160, 120, 30)
    )

    // 转换结果。
    sealed class ConvertResult {
        data class Success(val output: File) : ConvertResult()
        data class Failure(val message: String) : ConvertResult()
    }

    // 进度回调约定：onProgress(current, total)。
    //   total 大于 0 时可算百分比；total 等于 0 表示总量未知（用已处理帧数展示）。

    // ===================== 正向：MP4 到 AMV =====================
    fun mp4ToAmv(
        inputFile: File,
        outputFile: File,
        profile: AmvProfile,
        onProgress: (current: Int, total: Int) -> Unit
    ): ConvertResult {
        if (!inputFile.exists() || inputFile.length() == 0L) {
            return ConvertResult.Failure("输入文件不存在或为空：${inputFile.absolutePath}")
        }

        // 用安卓系统能力探测 MP4 的音轨与时长（MP4 是标准格式，系统支持良好）。
        val probe = probeMp4(inputFile)
        val total: Int =
            if (probe.durationSec > 0) (probe.durationSec * profile.fps).toInt().coerceAtLeast(1)
            else 0

        FFmpegKitConfig.enableStatisticsCallback { st ->
            onProgress(st.videoFrameNumber, total)
        }

        val args = buildAmvArgs(inputFile, outputFile, profile, hasAudio = probe.hasAudio)
        val session = FFmpegKit.executeWithArguments(args)
        FFmpegKitConfig.enableStatisticsCallback(null)

        return resultOf(session, outputFile, onProgress, total)
    }

    // ===================== 反向：AMV 到 MP4 =====================
    fun amvToMp4(
        inputFile: File,
        outputFile: File,
        onProgress: (current: Int, total: Int) -> Unit
    ): ConvertResult {
        if (!inputFile.exists() || inputFile.length() == 0L) {
            return ConvertResult.Failure("输入文件不存在或为空：${inputFile.absolutePath}")
        }

        // AMV 不是系统认识的格式，拿不到可靠时长，进度只用已处理帧数展示（total 传 0）。
        FFmpegKitConfig.enableStatisticsCallback { st ->
            onProgress(st.videoFrameNumber, 0)
        }

        val args = buildMp4Args(inputFile, outputFile)
        val session = FFmpegKit.executeWithArguments(args)
        FFmpegKitConfig.enableStatisticsCallback(null)

        return resultOf(session, outputFile, onProgress, 0)
    }

    // ===================== 内部工具 =====================

    private fun resultOf(
        session: com.arthenica.ffmpegkit.FFmpegSession,
        outputFile: File,
        onProgress: (Int, Int) -> Unit,
        total: Int
    ): ConvertResult {
        return if (ReturnCode.isSuccess(session.returnCode)) {
            if (outputFile.exists() && outputFile.length() > 0) {
                onProgress(if (total > 0) total else 1, total)
                ConvertResult.Success(outputFile)
            } else {
                ConvertResult.Failure("转换返回成功，但未生成有效输出文件。")
            }
        } else {
            val log = session.allLogsAsString
            val tail = if (log != null && log.length > 4000) log.substring(log.length - 4000) else (log ?: "")
            ConvertResult.Failure("转换失败（returnCode=${session.returnCode}）。\n\n日志：\n$tail")
        }
    }

    private data class ProbeInfo(val hasAudio: Boolean, val durationSec: Double)

    // 用 MediaMetadataRetriever 探测（仅用于 MP4）。失败则保守地当作有音轨、未知时长。
    private fun probeMp4(file: File): ProbeInfo {
        val mmr = MediaMetadataRetriever()
        return try {
            mmr.setDataSource(file.absolutePath)
            val audioFlag = mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_HAS_AUDIO)
            val hasAudio = audioFlag != null && audioFlag.equals("yes", ignoreCase = true)
            val durMs = mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
            ProbeInfo(hasAudio, durMs / 1000.0)
        } catch (e: Exception) {
            ProbeInfo(hasAudio = true, durationSec = 0.0)
        } finally {
            try {
                mmr.release()
            } catch (e: Exception) {
                // 忽略释放异常
            }
        }
    }

    // 构造 MP4 到 AMV 的参数。必须用字符串数组：每个 token 独立，避免滤镜里的逗号冒号被错误拆分。
    // 含音轨：缩放保比加黑边到目标尺寸，重采帧率，转全范围 4:2:0，amv 视频，adpcm_ima_amv 音频。
    // 无音轨：用 anullsrc 注入静音，并显式选流加 shortest。
    private fun buildAmvArgs(
        inputFile: File,
        outputFile: File,
        p: AmvProfile,
        hasAudio: Boolean
    ): Array<String> {
        val w = p.width
        val h = p.height
        val bs = p.blockSize

        val vf = "scale=$w:$h:force_original_aspect_ratio=decrease," +
                "pad=$w:$h:(ow-iw)/2:(oh-ih)/2:black," +
                "fps=${p.fps}," +
                "format=yuvj420p"

        val args = ArrayList<String>()
        args.add("-y")
        args.add("-i"); args.add(inputFile.absolutePath)
        if (!hasAudio) {
            args.add("-f"); args.add("lavfi")
            args.add("-i"); args.add("anullsrc=channel_layout=mono:sample_rate=$SAMPLE_RATE")
        }
        args.add("-map"); args.add("0:v:0")
        if (hasAudio) {
            args.add("-map"); args.add("0:a:0")
        } else {
            args.add("-map"); args.add("1:a:0")
        }
        args.add("-vf"); args.add(vf)
        args.add("-c:v"); args.add("amv")
        args.add("-strict"); args.add("-1")
        args.add("-c:a"); args.add("adpcm_ima_amv")
        args.add("-ar"); args.add(SAMPLE_RATE.toString())
        args.add("-ac"); args.add("1")
        args.add("-block_size"); args.add(bs.toString())
        if (!hasAudio) {
            args.add("-shortest")
        }
        args.add("-f"); args.add("amv")
        args.add(outputFile.absolutePath)
        return args.toTypedArray()
    }

    // 构造 AMV 到 MP4 的参数：保留源分辨率与帧率，转 H.264 加 AAC。
    // AMV 视频是全范围 yuvj420p，统一转 yuv420p 以获得最广播放器兼容性。
    private fun buildMp4Args(inputFile: File, outputFile: File): Array<String> {
        return arrayOf(
            "-y",
            "-i", inputFile.absolutePath,
            "-c:v", "libx264",
            "-pix_fmt", "yuv420p",
            "-crf", "23",
            "-c:a", "aac",
            "-b:a", "96k",
            "-ar", SAMPLE_RATE.toString(),
            "-movflags", "+faststart",
            "-f", "mp4",
            outputFile.absolutePath
        )
    }
}
