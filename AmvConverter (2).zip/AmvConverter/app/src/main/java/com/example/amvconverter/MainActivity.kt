package com.example.amvconverter

import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.example.amvconverter.AmvConverter.Direction
import com.example.amvconverter.databinding.ActivityMainBinding
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    // 当前转换方向。
    private var direction = Direction.MP4_TO_AMV

    // 用户选中的输入文件。
    private var inputUri: Uri? = null
    private var inputName: String? = null

    // AMV 输出参数（仅正向使用）。
    private val profiles = AmvConverter.PRESETS
    private var selectedProfile = profiles.first()

    // 选择输入文件。
    private val pickFile =
        registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            if (uri != null) {
                inputUri = uri
                inputName = queryDisplayName(uri)
                binding.tvInputFile.text = inputName ?: uri.toString()
                binding.btnConvert.isEnabled = true
                setStatus("已选择输入：${inputName ?: uri}")
            }
        }

    // 创建输出文件，拿到 URI 后立即开始转换。用通配类型，靠文件名后缀区分 amv 与 mp4。
    private val createOutput =
        registerForActivityResult(ActivityResultContracts.CreateDocument("*/*")) { uri ->
            if (uri != null) {
                startConversion(uri)
            } else {
                setBusy(false)
                setStatus("已取消保存。")
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // 方向选择。
        binding.rgDirection.setOnCheckedChangeListener { _, checkedId ->
            direction = if (checkedId == binding.rbToMp4.id) Direction.AMV_TO_MP4 else Direction.MP4_TO_AMV
            onDirectionChanged()
        }

        // AMV 参数下拉框。
        val adapter = ArrayAdapter(
            this,
            android.R.layout.simple_spinner_item,
            profiles
        ).also { it.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item) }
        binding.spinnerProfile.adapter = adapter
        binding.spinnerProfile.onItemSelectedListener =
            object : AdapterView.OnItemSelectedListener {
                override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                    selectedProfile = profiles[position]
                }

                override fun onNothingSelected(parent: AdapterView<*>?) {}
            }

        binding.btnPick.setOnClickListener {
            pickFile.launch(inputMimeFilter())
        }

        binding.btnConvert.setOnClickListener {
            val name = inputName ?: "output"
            val base = name.substringBeforeLast('.', name)
            val outName = if (direction == Direction.MP4_TO_AMV) "$base.amv" else "$base.mp4"
            setBusy(true)
            setStatus("选择输出位置…")
            createOutput.launch(outName)
        }

        binding.btnConvert.isEnabled = false
        resetProgress()
        onDirectionChanged()
    }

    // 方向变化时刷新文案、参数区可见性，并清空已选输入（类型不同）。
    private fun onDirectionChanged() {
        inputUri = null
        inputName = null
        binding.tvInputFile.text = "尚未选择文件"
        binding.btnConvert.isEnabled = false
        resetProgress()
        if (direction == Direction.MP4_TO_AMV) {
            binding.btnPick.text = "选择 MP4 文件…"
            binding.profileSection.visibility = View.VISIBLE
            binding.btnConvert.text = "转换为 AMV"
            setStatus("模式：MP4 转 AMV")
        } else {
            binding.btnPick.text = "选择 AMV 文件…"
            binding.profileSection.visibility = View.GONE
            binding.btnConvert.text = "转换为 MP4"
            setStatus("模式：AMV 转 MP4")
        }
    }

    // 输入选择器的类型过滤：MP4 用视频类型；AMV 系统多半不认识，用通配类型才选得到。
    private fun inputMimeFilter(): Array<String> =
        if (direction == Direction.MP4_TO_AMV) arrayOf("video/*") else arrayOf("*/*")

    // 转换流程：拷贝输入到缓存，调引擎，拷贝结果回输出位置，清理。
    private fun startConversion(outputUri: Uri) {
        val srcUri = inputUri
        if (srcUri == null) {
            setBusy(false)
            toast("请先选择输入文件")
            return
        }
        val dir = direction
        val profile = selectedProfile

        lifecycleScope.launch {
            resetProgress()
            setStatus("准备中：拷贝输入文件…")

            val result = withContext(Dispatchers.IO) {
                val inExt = if (dir == Direction.MP4_TO_AMV) "mp4" else "amv"
                val outExt = if (dir == Direction.MP4_TO_AMV) "amv" else "mp4"
                val cacheIn = File(cacheDir, "amv_in.$inExt")
                val cacheOut = File(cacheDir, "amv_out.$outExt")
                cacheIn.delete(); cacheOut.delete()

                // 1) 输入 URI 拷到缓存本地文件。
                try {
                    contentResolver.openInputStream(srcUri).use { input ->
                        if (input == null) error("无法打开输入文件")
                        cacheIn.outputStream().use { input.copyTo(it) }
                    }
                } catch (e: Exception) {
                    return@withContext AmvConverter.ConvertResult.Failure("拷贝输入失败：${e.message}")
                }

                runOnUiThread { setStatus("转换中…") }

                // 2) 按方向执行。
                val r = if (dir == Direction.MP4_TO_AMV) {
                    AmvConverter.mp4ToAmv(cacheIn, cacheOut, profile) { cur, tot ->
                        runOnUiThread { showProgress(cur, tot) }
                    }
                } else {
                    AmvConverter.amvToMp4(cacheIn, cacheOut) { cur, tot ->
                        runOnUiThread { showProgress(cur, tot) }
                    }
                }

                // 3) 成功则把产物拷回输出 URI。
                if (r is AmvConverter.ConvertResult.Success) {
                    try {
                        contentResolver.openOutputStream(outputUri).use { out ->
                            if (out == null) error("无法打开输出位置")
                            cacheOut.inputStream().use { it.copyTo(out) }
                        }
                    } catch (e: Exception) {
                        cacheIn.delete(); cacheOut.delete()
                        return@withContext AmvConverter.ConvertResult.Failure("写出结果失败：${e.message}")
                    }
                }

                // 4) 清理临时文件。
                cacheIn.delete(); cacheOut.delete()
                r
            }

            setBusy(false)
            when (result) {
                is AmvConverter.ConvertResult.Success -> {
                    finishProgress()
                    val what = if (dir == Direction.MP4_TO_AMV) "AMV" else "MP4"
                    setStatus("完成！已保存为 $what 文件。")
                    toast("转换完成")
                }
                is AmvConverter.ConvertResult.Failure -> {
                    setStatus("失败：\n${result.message}")
                    toast("转换失败")
                }
            }
        }
    }

    // 界面小工具

    private fun setBusy(busy: Boolean) {
        binding.btnConvert.isEnabled = !busy && inputUri != null
        binding.btnPick.isEnabled = !busy
        binding.spinnerProfile.isEnabled = !busy
        binding.rbToAmv.isEnabled = !busy
        binding.rbToMp4.isEnabled = !busy
    }

    // total 大于 0 显示百分比；等于 0（如 AMV 转 MP4）用不确定进度加帧号。
    private fun showProgress(current: Int, total: Int) {
        if (total > 0) {
            binding.progress.isIndeterminate = false
            val pct = (current.toLong() * 100L / total).toInt().coerceIn(0, 99)
            binding.progress.progress = pct
            binding.tvPercent.text = "$pct%"
        } else {
            binding.progress.isIndeterminate = true
            binding.tvPercent.text = if (current > 0) "$current 帧" else "…"
        }
    }

    private fun resetProgress() {
        binding.progress.isIndeterminate = false
        binding.progress.progress = 0
        binding.tvPercent.text = "0%"
    }

    private fun finishProgress() {
        binding.progress.isIndeterminate = false
        binding.progress.progress = 100
        binding.tvPercent.text = "100%"
    }

    private fun setStatus(msg: String) {
        binding.tvStatus.text = msg
    }

    private fun toast(msg: String) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
    }

    // 从 content URI 取显示文件名。
    private fun queryDisplayName(uri: Uri): String? {
        return try {
            contentResolver.query(uri, null, null, null, null)?.use { c ->
                val idx = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (idx >= 0 && c.moveToFirst()) c.getString(idx) else null
            }
        } catch (e: Exception) {
            null
        }
    }
}
